import json

from flask import Flask, request
from trucks.trucks import Trucks

app = Flask(__name__)

@app.route("/trucks", methods=["GET"])
def get_trucks():
	return json.dumps({"data": Trucks.fetch_all()})

@app.route("/trucks", methods=["POST"])
def add_truck():
	data = request.get_json()
	print(data)
	Trucks.create(
		data['truck_no'],
		data['truck_type'],
		data['driver_name'],
		data['driver_phone'],
		data['owner_name'],
		data['owner_phone']
	)
	return json.dumps({'msg': "Successfully registered truck."})

if __name__ == "__main__":
	app.run(debug=True, host="0.0.0.0")