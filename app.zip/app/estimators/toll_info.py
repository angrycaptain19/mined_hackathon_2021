import requests
import urllib.request as r
import json

from bs4 import BeautifulSoup as bsoup

import time

# Configurations for other API Options
"""
* Vehicle Options
- Car/Jeep/Van = car
- Bus/Truck = bus&t
- 3 Axle = 3axle
- 4 - 6 Axle = 4axle
- 7 or more Axle = 7axle
- HCM/EME = hcm
"""

# i = 1

# while (True):
# 	resp = r.urlopen("https://www.tollbetween.com/calculatetollcharges_db.php?v=car&t=single&j=Ahmedabad,%20India&e=Delhi,%20India&vc=")
# 	soup = bsoup(resp, "html5lib")
# 	print(soup)
# 	for tr in soup.find_all("tr")[1:]:
# 		td = tr.find_all("td")
# 		toll_name, toll_cost = td[0].text, td[1].text
# 		print("====== Attempt %s ======", i)
# 		print(toll_name, toll_cost)
# 	time.sleep(3)
# 	i+=1

import toll