import mysql.connector

# Database configurations
HOST = "18.207.0.75"
USER = "root"
PSWD = "bravoisalpha"

def get_connection():
	db = mysql.connector.connect(
		host=HOST,
		user=USER,
		password=PSWD,
		database="hackathon"
	)
	return db


class Trucks:

	@staticmethod
	def create(truck_no, truck_type, driver_name, driver_phone, owner_name, owner_phone):
		query = """
		INSERT INTO trucks(
			truck_no,
			truck_type,
			driver_name,
			driver_phone,
			owner_name,
			owner_phone
		) VALUES (
			'{}',
			'{}',
			'{}',
			'{}',
			'{}',
			'{}'
		);""".format(truck_no, truck_type, driver_name, driver_phone, owner_name, owner_phone)
		db = get_connection()
		cursor = db.cursor()
		cursor.execute(query)
		db.commit()

	@staticmethod
	def fetch_all():
		query = """SELECT * FROM trucks;"""
		db = get_connection()
		cursor = db.cursor()
		cursor.execute(query)
		results = cursor.fetchall()
		return [{
			"truck_no": r[0],
			"truck_type": r[1],
			"truck_id": r[2],
			"driver_name": r[3],
			"driver_phone": r[4],
			"owner_name": r[5],
			"owner_phone": r[6]
		} for r in results]